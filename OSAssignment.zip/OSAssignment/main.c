/** Author: Rebecca Clarke 17032866 */

/** Librarys Included */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    char selection;

	printf("1 - First come first served (FCFS) scheduler"); /**  This Print F Block Prints the menu choices*/
	printf("\n2 - Round robin (RR) scheduler");
    printf("\n3 - Shortest job first (SJF) scheduler");
	printf("\n4 - Quit");
	printf("\nEnter a selection: ");
	scanf("%c", &selection); /** Scan The Input  "%c" Is searching for a "character/char", this is often referred to as a string in Java"*/

	switch (selection)
	 /** Purpose: The purpose of this function is to switch between code from the menu choice given
    * Explanation: This function gets given a parameter from the user and goes to that particular case
    * Parameters: The user inputs a number 1-4 and this gets stored in $selection
    * Returns: Code for each algorithm depending on what number is entered  */
	{
        case '1':;

		int waitt[10]; /**< wait time */
		int n = 6; /**< number of processes */
		int at[10] ;/**< arrival time of all processes  */
		int bt[10] ; /**< burst time of all processes   */
		int tat[10]; /**<turn around time */
		int pid[10] = { 0,1,2,3,4,5};  /** Process ID 0-5*/
		int i; /**Initialising "Int i" for the for loop */

		float awt, atat; /** Float Average Wait time and Average Turn Around Time*/

		/** For loop to get all the burst time and arrival time of processes */
		for(i=0;i<n;i++)
        {
            printf("Enter Burst Time of process %d:",i+1);
            scanf("%d",&bt[i]); /**Assigning Burst Time to BT Array */
            printf("Enter Arrival Time of process %d:",i+1);
            scanf("%d",&at[i]);/**Assigning Arrival Time to AT Array */
        }

		printf("---------------------------------");
		printf("\n FCFS CPU Scheduling Algorithmn \n");
		printf("---------------------------------\n");

		/** This is the start of calculating the algorithm */

		waitt[0] = 0; /** Wait time Array = 0 */
		atat = tat[0] = bt[0]; /** average turn around time = turn around time = burst time */
		int btt = bt[0]; /**Integer "Btt" is to store total burst time sum */

		for (i = 1; i < n; i++)
       /** Purpose: The purpose of this function is to make a loop in which it works out the algorithm
       until all the processes have been worked out.
    * Explanation: This takes a inital value of 1 from an int and increases until it reaches more than N (the number of processes)
    * Parameters: int N (Number of processes) Int I (Initaliser for increase in loop) */
		{
			waitt[i] = btt - at[i]; /** wait time = burst time sum - arrival time*/
			btt += bt[i]; /**burst time sum = burst time  sum + burst time */
			awt += waitt[i]; /**average wait time  = average wait time + wait time */
			tat[i] = waitt[i] + bt[i]; /**turn around time = wait time + burst time */
			atat += tat[i]; /**average turn around time = average turn around time + turn around time */
		}

        atat /= n; /**average turn around time on new line */
		awt /= n; /** average wait time on new line*/

		/**displaying the table */
		printf("PID\tAT\tBT\tTAT\tWT\n"); /**Printing Table Headings */

		for (int l = 0; l < n; l++) /**For Loop */
		{
			printf("%6d\t%6d\t%6d\t%6d\t%6d\n", l+1, at[l], bt[l], tat[l], waitt[l]);  /**Printing actual table information */
        }

		printf("Average turn around time: %f\nAverage Wait time: %f", atat, awt); /**Printing average turn around and average wait time */

		break; /**Exit the switch statement case */
		return 0; /** Exit status (Program worked fine) */

		case '2':; /** Time Quantum =  1 */
		int BurstTimeRR[100];
		int WaitingTimeRR[100];
		int TurnAroundTimeRR[100];
		int ArrivalTimeRR[100];
		int a[100]; int b[100]; /** Array Functions */
		int k; int j = 0; int time;int count = 0; /** For Loops */
		float totalwt = 0, totalTT = 0, avgwt, avgtt; /** Float for Total Waiting Time, Total Turn around time, Average Wait Time, Average Turn Around Time*/

		printf("Enter total number of process : ");
		scanf("%d", &j); /** Assign Number of processes entered to variable J */

		/** For loop to get all the arrival times of processes */
		for (k = 0 ; k < j; k++)
		{
			printf("Enter the Arrival Time of process %d:" ,k + 1);
			scanf("%d", &ArrivalTimeRR[k]);
			a[k] = ArrivalTimeRR[k]; /**Assigning the array of a[k] to the arrival times of processes entered to the array of "arrivaltime[k]" */
		}

        /** For loop to get all the burst time of processes */
		for (k = 0 ; k < j; k++)
		{
			printf("Enter the Burst Time of process %d: ", k +1 );
			scanf("%d", &BurstTimeRR[k]);
			b[k] = BurstTimeRR[k]; /**Assigning the array of a[k] to the burst time of processes entered to the array of "bursttime[k]" */
		}

        /** For Loop to determine burst time + turn around time */
        for (time = 0; count != j; time++)
		{
			while (BurstTimeRR[k] == 0) /** While burst time is equal to 0 */
			{
				k = (k + 1) % j; /** Increase K int by 1 and divide by number of processes */
			}
			BurstTimeRR[k]--; /** Removes time quantum from BT*/

			if (BurstTimeRR[k] == 0) /** If burst time is equal to 0 */
			{
				TurnAroundTimeRR[k] = time + 1; /** Set turn around time to time +1 (time = 1 as time is initalised as 0) */
				count++; /** Increase counter */
			}
			k = (k + 1) % j; /** Increase loop and divide by number of processes */
		}

		printf("---------------------------------");
		printf("\nRound Robin CPU Scheduling Algorithmn\n");
		printf("---------------------------------\n");

		/** Print table headings and information */
		printf("PID\tAT\tBT\tTAT\tWT\n");
		for (k = 0; k < j; k++)
		{
			WaitingTimeRR[k] = TurnAroundTimeRR[k] - b[k]; /** Working out turn around time by taking wating time assigning the value to turn around time and taking away burst time */

			printf("%6d\t%6d\t%6d\t%6d\t%6d\n", k + 1, a[k], b[k], TurnAroundTimeRR[k], WaitingTimeRR[k]); /**Print out information in rows and columns */

			totalwt = totalwt + WaitingTimeRR[k]; /**Total wait time is equal to total wait time + waiting time array */
			totalTT = totalTT + TurnAroundTimeRR[k]; /**Total turn around time is equal to turn around time + turn around time array */
		}
		avgwt = totalwt / k; /** Average Waiting time is equal to total wait time divided by K (Time taken to complete the for loop) */
		avgtt = totalTT / k; /** Average Turn around  time is equal to total turn around time divided by K (Time taken to complete the for loop) */

		printf("Average turn around time: %f\nAverage Wait time: %f", avgtt, avgwt); /** Print out average turn around time and wait time */

        break; /**Exit the switch statement case */
		return 0; /** Exit status (Program worked fine) */

	case'3':;
    int s,e,p[10]={1,2,3,4,5,6,7,8,9,10};  int d; /** For Loop + Arrays */
    int min; int c=1; int temp;
    int burstT[10];
    int arrivalT[10];
    int waitT[10];
    int ta=0; int tt[10]; int sum = 0; int btime=0;
    float wavg=0; float tavg=0; float tsum=0; float wsum=0; /** Average time floats */


    printf("\nEnter the No. of processes :");
    scanf("%d",&e); /** Scanning for "%d" which refers to Integer and storing this in int e */


    	/** For loop to get all the arrival times of processes */
		for (s = 0 ; s < e; s++)
		{
			printf("\tEnter the arrival time of %d process:",s+1); /** Arrival Time User Input */
            scanf(" %d",&arrivalT[s]);
		}

		/** For loop to get all the burst time of processes */
		for(s=0;s<e;s++)
        {
          printf("\tEnter the burst time of %d process :",s+1); /** Burst Time User Input */
          scanf(" %d",&burstT[s]);
        }


    /**Sorting According to Arrival Time  (Re Arranging Arrays To Sort them)*/
    for(s=0;s<e;s++)
    {
        for(d=0;d<e;d++)
        {
            if(arrivalT[s]<arrivalT[d]) /** If Arrival Time s Array is less than Arrival Time d array */
            {
                temp = p[d]; /** Temp = p array of d */
                p[d] = p[s]; /** P Array of d is p Array of s */
                p[s]= temp; /** P Array of s = temp */
                temp = arrivalT[d]; /** Temp = Arrival Time of Array d */
                arrivalT[d] = arrivalT[s]; /** Arrival Time of d Array i = Arrival Time of s Array */
                arrivalT[s] = temp; /** Arrival Time of S Array = temp */
                temp = burstT[d]; /** Temp = Burst Time Array of d */
                burstT[d] = burstT[s]; /** Burst Time of d Array =  Burst Time of s Array */
                burstT[s] = temp; /** Burst Time of s Array = temp */
            }
        }
    }

    /**Arranging the table according to Burst time and Arrival Time */

    for(d=0;d<e;d++)
    {
        btime=btime+burstT[d]; /** btime = btime + Burst Time */
        min = burstT[c]; /** Min = Burst Time */
            for(s=c;s<e;s++)
            {
                if (btime >= arrivalT[s] && burstT[s]<min) /** If btime is less than or equal to arrival T (array of S) and Burst Time (array of S)is less than min */
                {
                    temp=p[c]; /** temp = P array of c */
                    p[c]=p[s]; /** P array of c  = P array of s */
                    p[s]=temp; /** P array of s = temp */
                    temp=arrivalT[c]; /** temp = Arrival Time array of c */
                    arrivalT[c]=arrivalT[s]; /** Arrival Time array of c = Arrival Time array of s */
                    arrivalT[s]=temp; /** Arrival Time array of S = temp*/
                    temp=burstT[c]; /** temp = Burst Time array of c */
                    burstT[c]=burstT[s]; /** Burst Time array of c = Burst Time array of s */
                    burstT[s]=temp; /** Burst Time array of s = temp*/
                } /** End of If loop */
            } /** End of for s= c loop */
        c++; /**Increase C int by 1 */
    } /** End of main FOR loop */

    waitT[0]=0; /** Set Waiting Time To 0 */

    /** WAITING TIME AVERAGE */
    for(s=1;s<e;s++)
    {
        sum = sum + burstT[s-1]; /** Sum = Sum + Burst Time */
        waitT[s]=sum-arrivalT[s]; /** Waiting Time = Sum  - Arrival Time */
        wsum=wsum+waitT[s]; /** Waiting Time Sum = Waiting Sum + Time Taken */
    }
    wavg = (wsum/e); /** Waiting Time Average = Waiting Time Sum / number of processes) */

    /** TURN AROUND TIME AVERAGE */
    for(s=0;s<e;s++)
    {
        ta = ta + burstT[s]; /** Turn Around = Turn Around + Bust Time */
        tt[s]= ta - arrivalT[s]; /** Time Taken = Turn Around Time - Arrival Time */
        tsum = tsum + tt[s]; /** Turn Around Sum = Turn Around Sum + Time Taken */
    }
    tavg =(tsum/e); /** Turn Around Average = Turn Around Sum / number of processes) */

    printf("---------------------------------");
    printf("\nShortest Job First \n");
    printf("---------------------------------\n");

    printf("PID\tAT\tBT\tTAT\tWT\n"); /** Table Headings */

    for(s=0;s<e;s++)
    {
        printf("\n %d\t %d\t %d\t %d\t%d",p[s],arrivalT[s],burstT[s],tt[s],waitT[s]); /** Printing Information in table */
    }
    printf("\nAverage turn around time: %f\nAverage Wait time: %f", tavg, wavg); /** Printing Average Turn Around Time, Average Wait Time */

    break;
    return 0;

    /**Exit Program Case */
	case '4':;
    exit(0);
    break;

    /** If No option is chosen from 1-4 this option will display */
    default: printf("error ! please enter valid menu option");

	}  /**End  of switch statement */

	return 0;  /**Exit Status (Program worked fine) */

} /**End of Code */

